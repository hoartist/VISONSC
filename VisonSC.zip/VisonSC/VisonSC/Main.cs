﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VisonSC
{
    //저자 :이용호
    //visonSC

    public class Main
    {
        byte[] Buffer;//버퍼이미지
        
        

        public void ConnectDevice(string DeviceName,int DeviceNo)
        {
            if (DeviceName == ""||DeviceNo!=0) { }
           
        }
        

        //이미지 저장
        public void GetImage()
        {

        }
        //이미지 불러오기


        //이미지 리사이즈



    }
}
