﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Log
    {

    //로그 파일 생성

    //로그 레코드
    public static void LogRecord(string DateTime,string Message)
    {
        Console.WriteLine(string.Format("{0},{1}", DateTime, Message));
    }
  
}
